#!/system/bin/sh

chmod -R 0755 "$MODPATH/common/addon/Volume-Key-Selector/tools"
alias keycheck="$MODPATH/common/addon/Volume-Key-Selector/tools/$ARCH32/keycheck"

keytest() {
	ui_print "[*] Vol Key Test"
	ui_print "    Press a Vol Key:"
	ui_print ""
	(timeout 3 /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" >"$TMPDIR/events") && return 0 || {
		ui_print "[*]   Try again:"
		timeout 3 keycheck
		SEL=$?
		[[ "$SEL" -eq "143" ]] && abort "[!]    Vol key not detected!" || return 1
	}
}

chooseport() {
	# Original idea by chainfire @xda-developers, improved on by ianmacd @xda-developers
	#note from chainfire @xda-developers: getevent behaves weird when piped, and busybox grep likes that even less than toolbox/toybox grep
	while true; do
		/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" >"$TMPDIR/events"
		($(cat "$TMPDIR/events" 2>/dev/null | /system/bin/grep VOLUME >/dev/null)) && break
	done
	($(cat "$TMPDIR/events" 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null)) && return 0 || return 1
}

chooseportold() {
	# Keycheck binary by someone755 @Github, idea for code below by Zappo @xda-developers
	# Calling it first time detects previous input. Calling it second time will do what we want
	while true; do
		keycheck
		keycheck
		SEL=$?
		[[ "$1" == "UP" ]] && {
			UP=$SEL
			break
		} || [[ "$1" == "DOWN" ]] && {
			DOWN=$SEL
			break
		} || [[ "$SEL" -eq "$UP" ]] && return 0 || [[ "$SEL" -eq "$DOWN" ]] && return 1
	done
}

# Have user option to skip vol keys
OIFS=$IFS
IFS=\|
MID=false
NEW=false
case $(echo $(basename "$ZIPFILE") | tr '[:upper:]' '[:lower:]') in
	*novk*) ui_print "[*] Skipping Vol Keys " ;;
	*) keytest && VKSEL=chooseport || {
		VKSEL=chooseportold
		ui_print "[!] Legacy device detected! Using old keycheck method."
		ui_print ""
		ui_print "[*] You can also setup a config file at the internal storage"
		sleep 3
		ui_print "    Name it ktsr_install.conf"
		sleep 3
		ui_print "	  Then set the parameters according to the values in the options here"
		ui_print "	  Available parameters: kingxvision, kingunlocker, gpurenderer, props, prof, delay, branch"
		ui_print " 	 E.G: kingxvision=1"
		ui_print "		   gpurenderer=1"
		sleep 8
		ui_print ""
		ui_print "[*] Vol Key Programming "
		ui_print "  Press Vol Up Again:"
		$VKSEL "UP"
		ui_print "  Press Vol Down"
		ui_print ""
		$VKSEL "DOWN"
	} ;;
esac
IFS=$OIFS
