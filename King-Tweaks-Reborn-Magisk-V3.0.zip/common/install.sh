#!/system/bin/sh
# KTSR™ by pedro (pedrozzz0 @ GitHub)
# Thanks to Akira (akirasupr @ GitHub), Taylo (V9y_7V2 @ Telegram)
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s).

modpath="/data/adb/modules_update/KTSR/"
config="/data/media/0/ktsr_install.conf"

# Android SDK
sdk=$(getprop ro.build.version.sdk)
[[ "$sdk" == "" ]] && sdk=$(getprop ro.vendor.build.version.sdk)
[[ "$sdk" == "" ]] && sdk=$(getprop ro.vndk.version)

# Max refresh rate available
rr=$(dumpsys display 2>/dev/null | awk '/PhysicalDisplayInfo/{print $4}' | cut -c1-3 | tr -d .)

[[ -z "$rr" ]] && rr=$(dumpsys display 2>/dev/null | grep refreshRate | awk -F '=' '{print $6}' | cut -c1-3 | tail -n 1 | tr -d .)

[[ -z "$rr" ]] && rr=$(dumpsys display 2>/dev/null | grep FrameRate | awk -F '=' '{print $6}' | cut -c1-3 | tail -n 1 | tr -d .)

sf_offset=$(getprop debug.sf.high_fps_early_gl_phase_offset_ns)

case "$sdk" in
	"31")
		sed -i '/persist.sys.fflag.override.settings_bluetooth_hearing_aid/s/.*/persist.sys.fflag.override.settings_bluetooth_hearing_aid=true/' "${modpath}system1.prop"
		sed -i '/persist.sys.fflag.override.settings_bluetooth_hearing_aid/s/.*/persist.sys.fflag.override.settings_bluetooth_hearing_aid=true/' "${modpath}system.prop"
		;;
	"30")
		sed -i '/persist.sys.fflag.override.settings_bluetooth_hearing_aid/s/.*/persist.sys.fflag.override.settings_bluetooth_hearing_aid=true/' "${modpath}system1.prop"
		sed -i '/sys.fflag.override.settings_seamless_transfer/s/.*/sys.fflag.override.settings_seamless_transfer=true/' "${modpath}system1.prop"
		sed -i '/persist.sys.fflag.override.settings_bluetooth_hearing_aid/s/.*/persist.sys.fflag.override.settings_bluetooth_hearing_aid=true/' "${modpath}system.prop"
		sed -i '/sys.fflag.override.settings_seamless_transfer/s/.*/sys.fflag.override.settings_seamless_transfer=true/' "${modpath}system.prop"
		;;
	"29")
		sed -i '/persist.sys.fflag.override.settings_network_and_internet_v2/s/.*/persist.sys.fflag.override.settings_network_and_internet_v2=true/' "${modpath}system1.prop"
		sed -i '/sys.fflag.override.settings_seamless_transfer/s/.*/sys.fflag.override.settings_seamless_transfer=true/' "${modpath}system1.prop"
		sed -i '/persist.sys.fflag.override.settings_network_and_internet_v2/s/.*/persist.sys.fflag.override.settings_network_and_internet_v2=true/' "${modpath}system.prop"
		sed -i '/sys.fflag.override.settings_seamless_transfer/s/.*/sys.fflag.override.settings_seamless_transfer=true/' "${modpath}system.prop"
		;;
esac

[[ "$sdk" -ge "29" ]] && [[ "$sdk" -ne "31" ]] && {
	sed -i '/persist.device_config.runtime_native.usap_pool_enabled/s/.*/persist.device_config.runtime_native.usap_pool_enabled=true/' "${modpath}system1.prop"
	sed -i '/persist.device_config.runtime_native.usap_pool_enabled/s/.*/persist.device_config.runtime_native.usap_pool_enabled=true/' "${modpath}system.prop"
}

[[ "$IS64BIT" == "true" ]] && {
	sed -i '/dalvik.vm.dex2oat64.enabled/s/.*/dalvik.vm.dex2oat64.enabled=true/' "${modpath}system1.prop"
	sed -i '/dalvik.vm.dex2oat64.enabled/s/.*/dalvik.vm.dex2oat64.enabled=true/' "${modpath}system.prop"
	sed -i '/arm64.memtag.process.system_server/s/.*/arm64.memtag.process.system_server=off/' "${modpath}system1.prop"
	sed -i '/arm64.memtag.process.system_server/s/.*/arm64.memtag.process.system_server=off/' "${modpath}system.prop"
}

[[ "$total_ram" -ge "1024" ]] && [[ ! "$total_ram" -ge "2048" ]] && {
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=180/' "${modpath}system1.prop"
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=180/' "${modpath}system.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system1.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system.prop"
}

[[ "$total_ram" -ge "2048" ]] && [[ ! "$total_ram" -ge "3072" ]] && {
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=540/' "${modpath}system1.prop"
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=540/' "${modpath}system.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system1.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system.prop"
} || [[ "$total_ram" -ge "3072" ]] && [[ ! "$total_ram" -ge "4096" ]] && {
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system1.prop"
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system1.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system.prop"
}

[[ "$total_ram" -ge "4096" ]] && [[ ! "$total_ram" -ge "6144" ]] && {
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system1.prop"
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system1.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system.prop"
}

[[ "$total_ram" -ge "6144" ]] && [[ ! "$total_ram" -ge "7288" ]] && {
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system1.prop"
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system1.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=true/' "${modpath}system.prop"
}

[[ "$total_ram" -ge "7288" ]] && {
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system1.prop"
	sed -i '/ro.zram.first_wb_delay_mins/s/.*/ro.zram.first_wb_delay_mins=1440/' "${modpath}system.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=false/' "${modpath}system1.prop"
	sed -i '/persist.device_config.activity_manager.use_compaction/s/.*/persist.device_config.activity_manager.use_compaction=false/' "${modpath}system.prop"
}

[[ "$sf_offset" == "-4000000" ]] && {
	sed -i '/debug.sf.high_fps_early_gl_phase_offset_ns/s/.*/debug.sf.high_fps_early_gl_phase_offset_ns=-2000000/' "${modpath}system1.prop"
	sed -i '/debug.sf.high_fps_early_gl_phase_offset_ns/s/.*/debug.sf.high_fps_early_gl_phase_offset_ns=-2000000/' "${modpath}system.prop"
	sed -i '/debug.sf.high_fps_late_sf_phase_offset_ns/s/.*/debug.sf.high_fps_late_sf_phase_offset_ns=-2000000/' "${modpath}system1.prop"
	sed -i '/debug.sf.high_fps_late_sf_phase_offset_ns/s/.*/debug.sf.high_fps_late_sf_phase_offset_ns=-2000000/' "${modpath}system.prop"
	sed -i '/debug.sf.high_fps_early_phase_offset_ns/s/.*/debug.sf.high_fps_early_phase_offset_ns=-2000000/' "${modpath}system1.prop"
	sed -i '/debug.sf.high_fps_early_phase_offset_ns/s/.*/debug.sf.high_fps_early_phase_offset_ns=-2000000/' "${modpath}system.prop"
}

[[ "$sdk" -ge "33" ]] && {
	sed -i '/debug.sf.latch_unsignaled/s/.*/debug.sf.latch_unsignaled=false/' "${modpath}system1.prop"
	sed -i '/debug.sf.latch_unsignaled/s/.*/debug.sf.latch_unsignaled=false/' "${modpath}system.prop"
	sed -i '/debug.sf.auto_latch_unsignaled/s/.*/debug.sf.auto_latch_unsignaled=true/' "${modpath}system1.prop"
	sed -i '/debug.sf.auto_latch_unsignaled/s/.*/debug.sf.auto_latch_unsignaled=true/' "${modpath}system.prop"
}

get_install_config() {
	[[ -e "$config" ]] && {
		kxvopt="$(grep kingxvision "$config" | awk -F '=' '{print $2}')"
		kuopt="$(grep kingunlocker "$config" | awk -F '=' '{print $2}')"
		gpurendopt="$(grep gpurenderer "$config" | awk -F '=' '{print $2}')"
		propsopt="$(grep props "$config" | awk -F '=' '{print $2}')"
		profopt="$(grep prof "$config" | awk -F '=' '{print $2}')"
		delayopt="$(grep delay "$config" | awk -F '=' '{print $2}')"
		branchopt="$(grep branch "$config" | awk -F '=' '{print $2}')"
		hostsopt="$(grep hosts "$config" | awk -F '=' '{print $2}')"
	}
}
get_install_config

if [[ "$kxvopt" != "" ]] && [[ "$kxvopt" == "1" ]]; then
	FCTEXTAD1="Enable King Xvision KCAL preset"
	wget -O "${modpath}kcal.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kcal.sh" && sh "${modpath}kcal.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD1 "
	sleep 3
elif [[ "$kxvopt" != "" ]] && [[ "$kxvopt" == "2" ]]; then
	FCTEXTAD1="Don't enable King Xvision KCAL preset"
	ui_print ""
	ui_print "Selected: $FCTEXTAD1 "
	sleep 3
else
	ui_print ""
	ui_print "[*] Do you want to enable King Xvision KCAL Preset?"
	ui_print ""
	ui_print "[*] King Xvision brings you more vivid and beautiful colors, and also better balance between them."
	ui_print ""
	ui_print " Volume + = Switch option "
	ui_print ""
	ui_print " Volume - = Select option "
	ui_print ""
	ui_print " 1 - Yes "
	ui_print ""
	ui_print " 2 - No "
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	KL=1
	while true; do
		ui_print "  $KL"
		if "$VKSEL"; then
			KL=$((KL + 1))
		else
			break
		fi
		if [[ "$KL" -gt "2" ]]; then
			KL=1
		fi
	done

	case "$KL" in
		1)
			FCTEXTAD1="Enable King Xvision KCAL preset"
			wget -O "${modpath}kcal.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kcal.sh" && sh "${modpath}kcal.sh"
			;;
		2) FCTEXTAD1="Don't enable King Xvision KCAL preset" ;;
	esac

	ui_print ""
	ui_print "Selected: $FCTEXTAD1 "
	sleep 3
fi

FTN="/data/data/com.epicgames.fortnite/files/UE4Game/FortniteGame/FortniteGame/Saved/Config/Android/GameUserSettings.ini"
DBD="/data/data/com.bhvr.deadbydaylight/files/UE4Game/DeadByDaylight/DeadByDaylight/Saved/Config/Android/GameUserSettings.ini"
SC="/data/media/0/Android/data/com.lnrgame.roguelike/files/SettingDatas.dat"
LIFE="/data/media/0/Android/data/com.netease.mrzhna/files/netease/g66/Documents/configs/qualityconfig"
NS="/data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini"

if [[ "$kuopt" != "" ]] && [[ "$kuopt" == "1" ]]; then
	FCTEXTAD2="None"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "2" ]]; then
	FCTEXTAD2="CODM 120 FPS"
	sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "3" ]]; then
	FCTEXTAD2="Asphalt 9, CODM and BDM Max Settings"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "4" ]]; then
	FCTEXTAD2="LOL WR Max Settings"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "5" ]]; then
	FCTEXTAD2="Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "6" ]]; then
	FCTEXTAD2="PUBGM 90 FPS and Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "7" ]]; then
	FCTEXTAD2="CODM 120 FPS and Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "8" ]]; then
	FCTEXTAD2="LOL WR Max Settings and Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i '/ro.product.model/s/.*/ro.product.model=A2218/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=A2218/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "9" ]]; then
	FCTEXTAD2="PUBGM 90 FPS and Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "10" ]]; then
	FCTEXTAD2="Asphalt, CODM, BDM Max Settings and Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "11" ]]; then
	FCTEXTAD2="CODM 120 FPS and Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "11" ]]; then
	FCTEXTAD2="Asphalt, CODM, BDM Max Settings and Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "12" ]]; then
	FCTEXTAD2="Fortnite 60 FPS"
	am force-stop com.epicgames.fortnite
	sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "13" ]]; then
	FCTEXTAD2="LOL WR 120 FPS"
	sed -i '/ro.product.model/s/.*/ro.product.manufacturer=samsung/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.manufacturer=samsung/' "${modpath}system1.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9910/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9910/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "14" ]]; then
	FCTEXTAD2="PUBGM 90 FPS"
	sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "15" ]]; then
	FCTEXTAD2="Asphalt 9 and Sky Children of the Light 60 FPS"
	sed -i '/ro.product.model/s/.*/ro.product.model=GM1917/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=GM1917/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "16" ]]; then
	FCTEXTAD2="Game For Peace 90 FPS"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "17" ]]; then
	FCTEXTAD2="Forsaken World 120 FPS"
	sed -i '/ro.product.model/s/.*/ro.product.model=ZS673KS-1B063IN/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=ZS673KS-1B063IN/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "18" ]]; then
	FCTEXTAD2="LifeAfter 120 FPS"
	am force-stop com.netease.mrzhna 2>/dev/null
	sed -i 's/"frame": 1,/"frame": 4,/g' "$LIFE"
	sed -i 's/"frame": 2,/"frame": 4,/g' "$LIFE"
	sed -i 's/"frame": 3,/"frame": 4,/g' "$LIFE"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "19" ]]; then
	FCTEXTAD2="Super Clone 120 FPS"
	am force-stop com.lnrgame.roguelike 2>/dev/null
	sed -i 's/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":30,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":120,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/g' "$SC"
	sed -i 's/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":45,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":120,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/g' "$SC"
	sed -i 's/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":60,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":120,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/g' "$SC"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "20" ]]; then
	FCTEXTAD2="Dead by Daylight 120 FPS"
	am force-stop com.bhvr.deadbydaylight 2>/dev/null
	sed -i 's/FrameRateLimit=30/FrameRateLimit=120/g' "$DBD"
	sed -i 's/FrameRateLimit=60/FrameRateLimit=120/g' "$DBD"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "21" ]]; then
	FCTEXTAD2="PUBG: NS 90 FPS"
	am force-stop com.pubg.newstate 2>/dev/null
	sed -i 's/FrameRateLimit=30.000000/FrameRateLimit=90.000000/g' "$NS"
	sed -i 's/FrameRateLimit=60.000000/FrameRateLimit=90.000000/g' "$NS"
	sed -i 's/AudioQualityLevel=2/AudioQualityLevel=0/g' "$NS"
	sed -i 's/AudioQualityLevel=1/AudioQualityLevel=0/g' "$NS"
	sed -i 's/LastConfirmedAudioQualityLevel=2/LastConfirmedAudioQualityLevel=0/g' "$NS"
	sed -i 's/LastConfirmedAudioQualityLevel=1/LastConfirmedAudioQualityLevel=0/g' "$NS"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "22" ]]; then
	FCTEXTAD2="BGMI 90 FPS"
	sed -i '/ro.product.model/s/.*/ro.product.model=M2102K1C/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=M2102K1C/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
elif [[ "$kuopt" != "" ]] && [[ "$kuopt" == "23" ]]; then
	FCTEXTAD2="Free Fire 90 FPS"
	sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=asus/' "${modpath}system.prop"
	sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=asus/' "${modpath}system1.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=ASUS_Z01QD/' "${modpath}system.prop"
	sed -i '/ro.product.model/s/.*/ro.product.model=ASUS_Z01QD/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	sleep 2
else
	awk '{print}' "${modpath}common/ku_banner"
	sleep 3
	ui_print " [!] Warning: This may cause problems with MiCam and other system apps "
	ui_print "              And also will not work if you're using magiskhideprops or other like module. "
	ui_print ""
	ui_print " 1 - None "
	ui_print ""
	ui_print " 2 - Apply CODM 120 FPS "
	ui_print ""
	ui_print " 3 - Apply Asphalt and BDM Max Settings "
	ui_print ""
	ui_print " 4 - Apply LOL WR Max Settings "
	ui_print ""
	ui_print " 5 - Apply Fortnite 60 FPS (Override all FPS modes lower than 60 and doesn't change device model) "
	ui_print ""
	ui_print " 6 - Apply PUBGM 90 FPS and Fortnite 60 FPS "
	ui_print ""
	ui_print " 7 - Apply CODM 120 FPS and Fortnite 60 FPS "
	ui_print ""
	ui_print " 8 - Apply LOL WR Max Settings and Fortnite 60 FPS "
	ui_print ""
	ui_print " 9 - Apply PUBGM 90 FPS and Fortnite 60 FPS "
	ui_print ""
	ui_print " 10 - Apply CODM 120 FPS and Fortnite 60 FPS "
	ui_print ""
	ui_print " 11 - Asphalt, CODM, BDM Max Settings and Fortnite 60 FPS "
	ui_print ""
	ui_print " 12 - Apply Asphalt, CODM, BDM Max Settings and Fortnite 60 FPS "
	ui_print ""
	ui_print " 13 - Apply LOL WR 120 FPS "
	ui_print ""
	ui_print " 14 - Apply PUBGM (Global) 90 FPS "
	ui_print ""
	ui_print " 15 - Apply Asphalt 9 and Sky Children of the Light 60 FPS "
	ui_print ""
	ui_print " 16 - Apply Game for Peace 90 FPS "
	ui_print ""
	ui_print " 17 - Apply Forsaken World 60 FPS "
	ui_print ""
	ui_print " 18 - Apply LifeAfter 120 FPS "
	ui_print ""
	ui_print " 19 - Apply Super Clone 120 FPS "
	ui_print ""
	ui_print " 20 - Apply Dead by Daylight 120 FPS "
	ui_print ""
	ui_print " 21 - Apply PUBG: NS 90 FPS "
	ui_print ""
	ui_print " 22 - Apply BGMI 90 FPS "
	ui_print ""
	ui_print " 23 - Apply Free Fire 90 FPS"
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	KU=1
	while true; do
		ui_print "  $KU"
		if "$VKSEL"; then
			KU=$((KU + 1))
		else
			break
		fi
		if [[ "$KU" -gt "23" ]]; then
			KU=1
		fi
	done

	for GS in /data/media/0/Android/data/com.riotgames.league.wildrift/files/SaveData/Local/*/Setting; do
		case "$KU" in
			1) FCTEXTAD2="None" ;;
			2)
				FCTEXTAD2="CODM 120 FPS"
				sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system1.prop"
				;;
			3)
				FCTEXTAD2="Asphalt 9, CODM and BDM Max Settings"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system1.prop"
				;;
			4)
				FCTEXTAD2="LOL WR Max Settings"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system1.prop"
				;;
			5)
				FCTEXTAD2="Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				;;
			6)
				FCTEXTAD2="PUBGM 90 FPS and Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system1.prop"
				;;
			7)
				FCTEXTAD2="CODM 120 FPS and Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system1.prop"
				;;
			8)
				FCTEXTAD2="LOL WR Max Settings and Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i '/ro.product.model/s/.*/ro.product.model=A2218/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=A2218/' "${modpath}system1.prop"
				;;
			9)
				FCTEXTAD2="PUBGM 90 FPS and Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system1.prop"
				;;
			10)
				FCTEXTAD2="CODM 120 FPS and Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' "${modpath}system1.prop"
				;;
			11)
				FCTEXTAD2="Asphalt, CODM, BDM Max Settings and Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' "${modpath}system1.prop"
				;;
			12)
				FCTEXTAD2="Fortnite 60 FPS"
				am force-stop com.epicgames.fortnite
				sed -i 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				sed -i 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g' "$FTN"
				;;
			13)
				FCTEXTAD2="LOL WR 120 FPS"
				sed -i '/ro.product.model/s/.*/ro.product.manufacturer=samsung/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.manufacturer=samsung/' "${modpath}system1.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9910/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9910/' "${modpath}system1.prop"
				;;
			14)
				FCTEXTAD2="PUBGM 90 FPS"
				sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=IN2023/' "${modpath}system1.prop"
				;;
			15)
				FCTEXTAD2="Asphalt 9 and Sky Children of the Light 60 FPS"
				sed -i '/ro.product.model/s/.*/ro.product.model=GM1917/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=GM1917/' "${modpath}system1.prop"
				;;
			16)
				FCTEXTAD2="Game For Peace 90 FPS"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' "${modpath}system1.prop"
				;;
			17)
				FCTEXTAD2="Forsaken World 120 FPS"
				sed -i '/ro.product.model/s/.*/ro.product.model=ZS673KS-1B063IN/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=ZS673KS-1B063IN/' "${modpath}system1.prop"
				;;
			18)
				FCTEXTAD2="LifeAfter 120 FPS"
				am force-stop com.netease.mrzhna 2>/dev/null
				sed -i 's/"frame": 1,/"frame": 4,/g' "$LIFE"
				sed -i 's/"frame": 2,/"frame": 4,/g' "$LIFE"
				sed -i 's/"frame": 3,/"frame": 4,/g' "$LIFE"
				;;
			19)
				FCTEXTAD2="Super Clone 120 FPS"
				am force-stop com.lnrgame.roguelike 2>/dev/null
				sed -i 's/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":30,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":120,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/g' "$SC"
				sed -i 's/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":45,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":120,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/g' "$SC"
				sed -i 's/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":60,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/{"isFPSOn":true,"isEffectSoundOn":true,"isMusicSoundOn":true,"targetFPS":120,"isFixTouchJoystickPosition":true,"isFixTouchJoystickCompletely":true}/g' "$SC"
				;;
			20)
				FCTEXTAD2="Dead by Daylight 120 FPS"
				am force-stop com.bhvr.deadbydaylight 2>/dev/null
				sed -i 's/FrameRateLimit=30/FrameRateLimit=120/g' "$DBD"
				sed -i 's/FrameRateLimit=60/FrameRateLimit=120/g' "$DBD"
				;;
			21)
				FCTEXTAD2="PUBG: NS 90 FPS"
				am force-stop com.pubg.newstate 2>/dev/null
				sed -i 's/FrameRateLimit=30.000000/FrameRateLimit=90.000000/g' "$NS"
				sed -i 's/FrameRateLimit=60.000000/FrameRateLimit=90.000000/g' "$NS"
				sed -i 's/AudioQualityLevel=2/AudioQualityLevel=0/g' "$NS"
				sed -i 's/AudioQualityLevel=1/AudioQualityLevel=0/g' "$NS"
				sed -i 's/LastConfirmedAudioQualityLevel=2/LastConfirmedAudioQualityLevel=0/g' "$NS"
				sed -i 's/LastConfirmedAudioQualityLevel=1/LastConfirmedAudioQualityLevel=0/g' "$NS"
				;;
			22)
				FCTEXTAD2="BGMI 90 FPS"
				sed -i '/ro.product.model/s/.*/ro.product.model=M2102K1C/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=M2102K1C/' "${modpath}system1.prop"
				;;
			23)
				FCTEXTAD2="Free Fire 90 FPS"
				sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=asus/' "${modpath}system.prop"
				sed -i '/ro.product.manufacturer/s/.*/ro.product.manufacturer=asus/' "${modpath}system1.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=ASUS_Z01QD/' "${modpath}system.prop"
				sed -i '/ro.product.model/s/.*/ro.product.model=ASUS_Z01QD/' "${modpath}system1.prop"
				;;
		esac
		break
	done

	ui_print ""
	ui_print "Selected: $FCTEXTAD2 "
	ui_print ""
	sleep 2
fi

if [[ "$gpurendopt" != "" ]] && [[ "$gpurendopt" == "1" ]]; then
	FCTEXTAD3="No"
	ui_print ""
	ui_print "Selected: $FCTEXTAD3 "
	sleep 3
elif [[ "$gpurendopt" != "" ]] && [[ "$gpurendopt" == "2" ]]; then
	FCTEXTAD3="OpenGL"
	sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=opengl/' "${modpath}system.prop"
	sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=opengl/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD3 "
	sleep 3
elif [[ "$gpurendopt" != "" ]] && [[ "$gpurendopt" == "3" ]]; then
	FCTEXTAD3="OpenGL (Skia)"
	sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiagl/' "${modpath}system.prop"
	sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiagl/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD3 "
	sleep 3
elif [[ "$gpurendopt" != "" ]] && [[ "$gpurendopt" == "4" ]]; then
	FCTEXTAD3="Vulkan (Skia)"
	sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiavk/' "${modpath}system.prop"
	sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiavk/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD3 "
	sleep 3
else
	ui_print "[*] Do you want to change your GPU renderer?"
	ui_print ""
	ui_print "[!] Warning: If you face any screen glitches / bugs, try reinstalling and choosing the default option."
	ui_print ""
	ui_print " 1 - No "
	ui_print ""
	ui_print " 2 - OpenGL "
	ui_print ""
	ui_print " 3 - OpenGL (Skia) "
	ui_print ""
	ui_print " 4 - Vulkan (Skia) (Recommended) "
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	GRP=1
	while true; do
		ui_print "  $GRP"
		if "$VKSEL"; then
			GRP=$((GRP + 1))
		else
			break
		fi
		if [[ "$GRP" -gt "4" ]]; then
			GRP=1
		fi
	done

	case "$GRP" in
		1) FCTEXTAD3="No" ;;
		2)
			FCTEXTAD3="OpenGL"
			sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=opengl/' "${modpath}system.prop"
			sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=opengl/' "${modpath}system1.prop"
			;;
		3)
			FCTEXTAD3="OpenGL (Skia)"
			sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiagl/' "${modpath}system.prop"
			sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiagl/' "${modpath}system1.prop"
			;;
		4)
			FCTEXTAD3="Vulkan (Skia)"
			sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiavk/' "${modpath}system.prop"
			sed -i '/debug.hwui.renderer/s/.*/debug.hwui.renderer=skiavk/' "${modpath}system1.prop"
			;;
	esac

	ui_print ""
	ui_print "Selected: $FCTEXTAD3 "
	ui_print ""
	sleep 3
fi

if [[ "$propsopt" != "" ]] && [[ "$propsopt" == "1" ]]; then
	FCTEXTAD4="Yes"
	cp -f "${modpath}system1.prop" "${modpath}system.prop"
	rm -rf "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD4 "
	sleep 3
elif [[ "$propsopt" != "" ]] && [[ "$propsopt" == "2" ]]; then
	FCTEXTAD4="No"
	rm -rf "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD4 "
	sleep 3
else
	ui_print "[*] Do you want to install build.prop tweaks?"
	ui_print ""
	ui_print "[*] Build.prop tweaks intends to improve performance, battery life and overall smoothness"
	ui_print "But can also cause bootloop or unintended behaviour on some devices."
	ui_print ""
	ui_print " Volume + = Switch option "
	ui_print ""
	ui_print " Volume - = Select option "
	ui_print ""
	ui_print " 1 - Yes "
	ui_print ""
	ui_print " 2 - No "
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	BPT=1
	while true; do
		ui_print "  $BPT"
		if "$VKSEL"; then
			BPT=$((BPT + 1))
		else
			break
		fi
		if [[ "$BPT" -gt "2" ]]; then
			BPT=1
		fi
	done

	case "$BPT" in
		1)
			FCTEXTAD4="Yes"
			cp -f "${modpath}system1.prop" "${modpath}system.prop"
			rm -rf "${modpath}system1.prop"
			;;
		2)
			FCTEXTAD4="No"
			rm -rf "${modpath}system1.prop"
			;;
	esac

	ui_print ""
	ui_print "Selected: $FCTEXTAD4 "
	ui_print ""
	sleep 3
fi

if [[ "$profopt" != "" ]] && [[ "$profopt" == "1" ]]; then
	FCTEXTAD5="Automatic"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=1/' "${modpath}system.prop"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=1/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
	sleep 3
elif [[ "$profopt" != "" ]] && [[ "$profopt" == "2" ]]; then
	FCTEXTAD5="Battery"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=2/' "${modpath}system.prop"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=2/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
	sleep 3
elif [[ "$profopt" != "" ]] && [[ "$profopt" == "3" ]]; then
	FCTEXTAD5="Balanced"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=3/' "${modpath}system.prop"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=3/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
	sleep 3
elif [[ "$profopt" != "" ]] && [[ "$profopt" == "4" ]]; then
	FCTEXTAD5="Extreme"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=4/' "${modpath}system.prop"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=4/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
	sleep 3
elif [[ "$profopt" != "" ]] && [[ "$profopt" == "5" ]]; then
	FCTEXTAD5="Game"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=5/' "${modpath}system.prop"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=5/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
	sleep 3
elif [[ "$profopt" != "" ]] && [[ "$profopt" == "6" ]]; then
	FCTEXTAD5="Latency"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=6/' "${modpath}system.prop"
	sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=6/' "${modpath}system1.prop"
	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
	sleep 3
elif [[ "$profopt" != "" ]] && [[ "$profopt" == "7" ]]; then
	FCTEXTAD5="None"
	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
else
	ui_print "[*] Do you want to select a default KTSR profile?"
	ui_print ""
	ui_print "[*] Selecting a default KTSR profile will make the profile persist on reboot."
	ui_print ""
	ui_print " Volume + = Switch option "
	ui_print ""
	ui_print " Volume - = Select option "
	ui_print ""
	ui_print " 1 - Automatic "
	ui_print ""
	ui_print " 2 - Battery "
	ui_print ""
	ui_print " 3 - Balanced "
	ui_print ""
	ui_print " 4 - Extreme "
	ui_print ""
	ui_print " 5 - Game "
	ui_print
	ui_print " 6 - Latency "
	ui_print ""
	ui_print " 7 - None (You may need to set it manually once by the CLI (su -c ktsrmenu))."
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	KTRP=1
	while true; do
		ui_print "  $KTRP"
		if "$VKSEL"; then
			KTRP=$((KTRP + 1))
		else
			break
		fi
		if [[ "$KTRP" -gt "7" ]]; then
			KTRP=1
		fi
	done

	case "$KTRP" in
		1)
			FCTEXTAD5="Automatic"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=1/' "${modpath}system.prop"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=1/' "${modpath}system1.prop"
			;;
		2)
			FCTEXTAD5="Battery"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=2/' "${modpath}system.prop"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=2/' "${modpath}system1.prop"
			;;
		3)
			FCTEXTAD5="Balanced"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=3/' "${modpath}system.prop"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=3/' "${modpath}system1.prop"
			;;
		4)
			FCTEXTAD5="Extreme"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=4/' "${modpath}system.prop"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=4/' "${modpath}system1.prop"
			;;
		5)
			FCTEXTAD5="Game"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=5/' "${modpath}system.prop"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=5/' "${modpath}system1.prop"
			;;
		6)
			FCTEXTAD5="Latency"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=6/' "${modpath}system.prop"
			sed -i '/persist.king.tweaks.prof/s/.*/persist.king.tweaks.prof=6/' "${modpath}system1.prop"
			;;
		7)
			FCTEXTAD5="None"
			;;
	esac

	ui_print ""
	ui_print "Selected: $FCTEXTAD5 "
	ui_print ""
	sleep 3
fi

if [[ "$delayopt" != "" ]] && [[ "$delayopt" == "1" ]]; then
	FCTEXTAD6="No"
	sed -i '/300/s/.*/sleep 1/' "${modpath}service.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD6 "
	sleep 4
elif [[ "$delayopt" != "" ]] && [[ "$delayopt" == "2" ]]; then
	FCTEXTAD6="30 secs"
	sed -i '/300/s/.*/sleep 30/' "${modpath}service.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD6 "
	sleep 4
elif [[ "$delayopt" != "" ]] && [[ "$delayopt" == "3" ]]; then
	FCTEXTAD6="1 min"
	sed -i '/300/s/.*/sleep 60/' "${modpath}service.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD6 "
	sleep 4
elif [[ "$delayopt" != "" ]] && [[ "$delayopt" == "4" ]]; then
	FCTEXTAD6="2 min"
	sed -i '/300/s/.*/sleep 120/' "${modpath}service.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD6 "
	sleep 4
elif [[ "$delayopt" != "" ]] && [[ "$delayopt" == "5" ]]; then
	FCTEXTAD6="3 min"
	sed -i '/300/s/.*/sleep 180/' "${modpath}service.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD6 "
	sleep 4
elif [[ "$delayopt" != "" ]] && [[ "$delayopt" == "6" ]]; then
	FCTEXTAD6="Default (5 Min)"
	ui_print ""
	ui_print "Selected: $FCTEXTAD6 "
	sleep 4
else
	ui_print "[*] Do you want to apply a delay at KTSR runtime?"
	ui_print ""
	ui_print "[*] Selecting a default KTSR runtime will make it more unlikely to random reboot / issues happen."
	ui_print ""
	ui_print " Volume + = Switch option "
	ui_print ""
	ui_print " Volume - = Select option "
	ui_print ""
	ui_print " 1 - No "
	ui_print ""
	ui_print " 2 - 30 Secs "
	ui_print ""
	ui_print " 3 - 1 Min "
	ui_print ""
	ui_print " 4 - 2 Min "
	ui_print ""
	ui_print " 5 - 3 Min "
	ui_print ""
	ui_print " 6 - Default (5 Min)"
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	KD=1
	while true; do
		ui_print "  $KD"
		if "$VKSEL"; then
			KD=$((KD + 1))
		else
			break
		fi
		if [[ "$KD" -gt "6" ]]; then
			KD=1
		fi
	done

	case "$KD" in
		1)
			FCTEXTAD6="No"
			sed -i '/300/s/.*/sleep 1/' "${modpath}service.sh"
			;;
		2)
			FCTEXTAD6="30 secs"
			sed -i '/300/s/.*/sleep 30/' "${modpath}service.sh"
			;;
		3)
			FCTEXTAD6="1 min"
			sed -i '/300/s/.*/sleep 60/' "${modpath}service.sh"
			;;
		4)
			FCTEXTAD6="2 mins"
			sed -i '/300/s/.*/sleep 120/' "${modpath}service.sh"
			;;
		5)
			FCTEXTAD6="3 mins"
			sed -i '/300/s/.*/sleep 180/' "${modpath}service.sh"
			;;
		6)
			FCTEXTAD6="Default (5 Min)"
			;;
	esac

	ui_print ""
	ui_print "Selected: $FCTEXTAD6 "
	ui_print ""
	sleep 4
fi

if [[ "$branchopt" != "" ]] && [[ "$branchopt" == "1" ]]; then
	FCTEXTAD7="Stable (Recommended)"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingtweaks/s/.*/wget -qO "${modpath}system\/bin\/kingtweaks" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/kingtweaks"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingd/s/.*/wget -qO "${modpath}system\/bin\/kingd" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/kingd"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libktsr.sh/s/.*/wget -qO "${modpath}libs\/libktsr.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/libktsr.sh"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libcommon.sh/s/.*/wget -qO "${modpath}libs\/libcommon.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/libcommon.sh"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/cleantrash/s/.*/wget -qO "${modpath}system\/bin\/cleantrash" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/cleantrash"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/ktsrmenu/s/.*/wget -qO "${modpath}system\/bin\/ktsrmenu" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/ktsrmenu"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/mod-util.sh/s/.*/wget -qO "${modpath}mod-util.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/mod-util.sh"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/mod-util.sh/s/.*/wget -qO "${modpath}system\/bin\/kingun" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/kingun"/' "${modpath}service.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD7 "
	ui_print ""
	sleep 3
elif [[ "$branchopt" != "" ]] && [[ "$branchopt" == "2" ]]; then
	FCTEXTAD7="Master (Default)"
	ui_print ""
	ui_print "Selected: $FCTEXTAD7 "
	ui_print ""
	sleep 3
elif [[ "$branchopt" != "" ]] && [[ "$branchopt" == "3" ]]; then
	FCTEXTAD7="Testing (Unstable)"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingtweaks/s/.*/wget -qO "${modpath}system\/bin\/kingtweaks" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/kingtweaks"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingd/s/.*/wget -qO "${modpath}system\/bin\/kingd" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/kingd"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libktsr.sh/s/.*/wget -qO "${modpath}libs\/libktsr.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/libktsr.sh"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libcommon.sh/s/.*/wget -qO "${modpath}libs\/libcommon.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/libcommon.sh"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/cleantrash/s/.*/wget -qO "${modpath}system\/bin\/cleantrash" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/cleantrash"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/ktsrmenu/s/.*/wget -qO "${modpath}system\/bin\/ktsrmenu" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/ktsrmenu"/' "${modpath}service.sh"
	sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/mod-util.sh/s/.*/wget -qO "${modpath}mod-util.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/mod-util.sh"/' "${modpath}service.sh"
	ui_print ""
	ui_print "Selected: $FCTEXTAD7 "
	ui_print ""
	sleep 3
else
	ui_print "[*] Select a default KTSR branch"
	ui_print ""
	ui_print "[*] The branch is from where the scripts will be downloaded from"
	ui_print "Different branches may have different changes from another accordingly, and also be experimental. (E.G: testing branch)"
	ui_print ""
	ui_print " Volume + = Switch option "
	ui_print ""
	ui_print " Volume - = Select option "
	ui_print ""
	ui_print " 1 - Stable (Recommended)"
	ui_print ""
	ui_print " 2 - Master (Default) "
	ui_print ""
	ui_print " 3 - Testing (May be unstable) "
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	bnch=1
	while true; do
		ui_print "  $bnch"
		if "$VKSEL"; then
			bnch=$((bnch + 1))
		else
			break
		fi
		if [[ "$bnch" -gt "3" ]]; then
			bnch=1
		fi
	done

	case "$bnch" in
		1)
			FCTEXTAD7="Stable (Recommended)"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingtweaks/s/.*/wget -qO "${modpath}system\/bin\/kingtweaks" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/kingtweaks"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingd/s/.*/wget -qO "${modpath}system\/bin\/kingd" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/kingd"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libktsr.sh/s/.*/wget -qO "${modpath}libs\/libktsr.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/libktsr.sh"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libcommon.sh/s/.*/wget -qO "${modpath}libs\/libcommon.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/libcommon.sh"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/cleantrash/s/.*/wget -qO "${modpath}system\/bin\/cleantrash" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/cleantrash"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/ktsrmenu/s/.*/wget -qO "${modpath}system\/bin\/ktsrmenu" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/ktsrmenu"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/mod-util.sh/s/.*/wget -qO "${modpath}mod-util.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/mod-util.sh"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/gameoptd/s/.*/wget -qO "${modpath}system\/bin\/gameoptd" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/gameoptd"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingun/s/.*/wget -qO "${modpath}system\/bin\/kingun" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/stable\/kingun"/' "${modpath}service.sh"
			;;
		2)
			FCTEXTAD7="Master (Default)"
			;;
		3)
			FCTEXTAD7="Testing (Unstable)"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingtweaks/s/.*/wget -qO "${modpath}system\/bin\/kingtweaks" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/kingtweaks"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/kingd/s/.*/wget -qO "${modpath}system\/bin\/kingd" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/kingd"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libktsr.sh/s/.*/wget -qO "${modpath}libs\/libktsr.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/libktsr.sh"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/libcommon.sh/s/.*/wget -qO "${modpath}libs\/libcommon.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/libcommon.sh"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/cleantrash/s/.*/wget -qO "${modpath}system\/bin\/cleantrash" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/cleantrash"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/ktsrmenu/s/.*/wget -qO "${modpath}system\/bin\/ktsrmenu" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/ktsrmenu"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/mod-util.sh/s/.*/wget -qO "${modpath}mod-util.sh" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/mod-util.sh"/' "${modpath}service.sh"
			sed -i '/https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/master\/gameoptd/s/.*/wget -qO "${modpath}system\/bin\/gameoptd" "https:\/\/raw.githubusercontent.com\/pedrozzz0\/King-Tweaks\/testing\/gameoptd"/' "${modpath}service.sh"
			;;
	esac

	ui_print ""
	ui_print "Selected: $FCTEXTAD7 "
	ui_print ""
	sleep 3
fi

if [[ "$hostsopt" != "" ]] && [[ "$hostsopt" == "1" ]]; then
	FCTEXTAD8="Yes (Recommended)"
	mkdir -p "${modpath}system/etc"
	wget -O "${modpath}system/etc/hosts" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/hosts.txt"
	ui_print ""
	ui_print "Selected: $FCTEXTAD8 "
	ui_print ""
	sleep 3
elif [[ "$hostsopt" != "" ]] && [[ "$hostsopt" == "2" ]]; then
	FCTEXTAD8="No"
	ui_print ""
	ui_print "Selected: $FCTEXTAD8 "
	ui_print ""
	sleep 3
else
	ui_print "[*] Do you want to apply KTSR hosts?"
	ui_print ""
	ui_print "[*] The hosts file is used to handle hostnames / IPs permissions"
	ui_print "    KTSR hosts block ad websites, trackers and also spyware for a better user-experience."
	ui_print ""
	ui_print " Volume + = Switch option "
	ui_print ""
	ui_print " Volume - = Select option "
	ui_print ""
	ui_print " 1 - Yes (Recommended)"
	ui_print ""
	ui_print " 2 - No"
	ui_print ""
	ui_print "[*] Select which you want: "
	ui_print ""
	hst=1
	while true; do
		ui_print "  $hst"
		if "$VKSEL"; then
			hst=$((hst + 1))
		else
			break
		fi
		if [[ "$hst" -gt "2" ]]; then
			hst=1
		fi
	done

	case "$hst" in
		1)
			FCTEXTAD8="Yes (Recommended)"
			mkdir -p "${modpath}system/etc"
			wget -O "${modpath}system/etc/hosts" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/hosts.txt"
			;;
		2)
			FCTEXTAD8="No"
			;;
	esac

	ui_print ""
	ui_print "Selected: $FCTEXTAD8 "
	ui_print ""
	sleep 3
fi

ui_print "[*] Done!"
ui_print ""

DESC="A full-featured optimizer which focus on maximize user-experience by tweaking both kernel and android settings, improving many segments of $(getprop ro.product.device) this way."
sed -i "/description=/c description=$DESC" "${modpath}module.prop"
