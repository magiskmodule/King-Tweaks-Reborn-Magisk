#!/system/bin/sh
# KTSR™ by Pedro (pedrozzz0 @ GitHub)
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s).

# Wait to boot be completed
until [[ "$(getprop sys.boot_completed)" -eq "1" ]] || [[ "$(getprop dev.bootcomplete)" -eq "1" ]]; do
	sleep 60
done

sleep 60

[[ ! -d "/data/adb/modules/KTSR/" ]] && [[ ! -d "$(pwd)/cleanup_done" ]] && {
	cmd looper_stats enable
	cmd dropbox set-rate-limit 2000
	settings reset global restrict_device_performance
	settings reset secure speed_mode_enable
	settings reset system hearing_aid
	cmd appops set com.android.backupconfirm RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set com.google.android.setupwizard RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set com.android.printservice.recommendation RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set com.google.android.feedback RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set com.google.android.onetimeinitializer RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set com.xiaomi.joyose RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set org.codeaurora.gps.gpslogsave RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set com.android.onetimeinitializer RUN_IN_BACKGROUND allow >/dev/null 2>&1
	cmd appops set com.qualcomm.qti.perfdump RUN_IN_BACKGROUND allow >/dev/null 2>&1
	rm -rf /data/media/0/KTSR 2>/dev/null
	rm -rf /data/media/0/ktsr 2>/dev/null
	service call SurfaceFlinger 1022 f 1.0 >/dev/null 2>&1
	pm enable com.samsung.android.game.gos >/dev/null 2>&1
	pm enable com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService >/dev/null 2>&1
	pm enable com.miui.systemAdSolution >/dev/null 2>&1
	pm enable com.miui.analytics >/dev/null 2>&1
	touch $(pwd)/cleanup_done
} || [[ ! -d "/data/adb/modules/KTSR/" ]] && [[ -e "$(pwd)/cleanup_done" ]] && {
	rm -rf "$(pwd)/cleanup_done"
	rm -rf "$(pwd)/ktsr-cleanup.sh"
}
