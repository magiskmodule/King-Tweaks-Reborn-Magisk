#!/system/bin/sh
# KTSR™ by pedro (pedrozzz0 @ GitHub, pedro3z0 @ Telegram)
# Thanks to AkumaHunt3r @ GitHub, Telegram
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s).
DEBUG=true
moddir="/data/adb/modules/"
mkdir -p "$MODPATH/system/bin"
mkdir -p "$MODPATH/libs"
rm -rf "/data/media/0/KTSR"
mkdir -p "/data/media/0/ktsr"
[[ ! -e "/data/media/0/ktsr_install.conf" ]] && echo "# Config file for KTSR installation
# Specify options according to installation to skip specific vol key events
# Always add a new line for every option, just like adjshield config file
kingxvision=
kingunlocker=
gpurenderer=
props=
prof=
delay=
branch=
hosts=" >"/data/media/0/ktsr_install.conf"
rm -rf \
	/data/media/0/ktsr/ktsr* \
	/data/media/0/ktsr/kx* \
	/data/media/0/ktsr/sqlite*
awk '{print}' "$MODPATH/common/ktsr_banner"
ui_print "Version: $(grep_prop version "$MODPATH/module.prop")"
ui_print ""
ui_print "KTSR™ is a full-featured tweaker / optimizer which focus on maximize user-experience"
ui_print ""
ui_print "It should improve performance, battery life, ram management and more."
ui_print ""
ui_print "If you like it, please consider sharing it to your friends, it means a lot. ❤️"
ui_print ""
ui_print "Credits:"
ui_print ""
ui_print "Thanks to Draco (tytydraco @ GitHub)"
ui_print ""
ui_print "Thanks to Matt Yang (yc9559 @ GitHub, CoolApk)"
ui_print ""
ui_print "Thanks to helloklf @ CoolApk"
ui_print ""
ui_print "Thanks to chenzyadb @ CoolApk"
ui_print ""
ui_print "Thanks to Taylo (V9y_7V2 @ Telegram)"
ui_print ""
ui_print "And a special thanks to everyone that supports my project since it's born and all the others projects also."
ui_print "With love, Pedro, #KeepTheKing. ♡"
ui_print ""
sleep 5

ui_print "[*] Fetching the latest script(s) from GitHub..."
wget -O "$MODPATH/system/bin/kingtweaks" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kingtweaks"
wget -O "$MODPATH/system/bin/kingd" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kingd"
wget -O "$MODPATH/system/bin/ktsrmenu" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/ktsrmenu"
wget -O "$MODPATH/system/bin/gameoptd" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/gameoptd"
wget -O "$MODPATH/system/bin/cleantrash" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/cleantrash"
wget -O "$MODPATH/system/bin/adjshield" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/adjshield"
wget -O "$MODPATH/system/bin/fscache-ctrl" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/fscache-ctrl"
wget -O "$MODPATH/mod-util.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/mod-util.sh"
wget -O "$MODPATH/libs/libktsr.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/libktsr.sh"
wget -O "$MODPATH/libs/libcommon.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/libcommon.sh"
wget -O "$MODPATH/system/bin/kingun" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kingun"

set_permissions() {
	set_perm_recursive "$MODPATH/system/bin" 0 0 0777 0755
	set_perm_recursive "$MODPATH/libs" 0 0 0777 0755
}

SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR/functions.sh"

ui_print ""
ui_print "[*] Fstrimming partitions..."
ui_print ""

fstrim /system
fstrim /system
fstrim /data
fstrim /data
fstrim /cache
fstrim /cache
fstrim /vendor
fstrim /vendor
fstrim /product
fstrim /product
sm fstrim

ui_print ""
ui_print "[*] Cleaning stuff..."
ui_print ""

[[ ! "$(command -v busybox)" ]] && {
	ui_print "[!] Busybox not installed"
	ui_print ""
	ui_print "[!] Please install it for full usage of KTSR"
	ui_print ""
}

[[ -d "${MODDIR}KTKSR/" ]] && rm -rf "${MODDIR}KTKSR" || [[ -d "${MODDIR}KTKS/" ]] && rm -rf "${MODDIR}KTKS"

ui_print "[*] Optimizing system settings..."
settings put global restrict_device_performance "0,0"
cmd power set-adaptive-power-saver-enabled true 2>/dev/null
settings put global enable_freeform_support 1
settings put system display_color_enhance 1
settings put system hearing_aid 1
cmd appops set com.xiaomi.joyose RUN_IN_BACKGROUND ignore >/dev/null 2>&1
cmd appops set org.codeaurora.gps.gpslogsave RUN_IN_BACKGROUND ignore >/dev/null 2>&1
cmd appops set com.qualcomm.qti.perfdump RUN_IN_BACKGROUND ignore >/dev/null 2>&1
ui_print ""
ui_print "[*] KTSR log(s) are stored in internal storage/ktsr"
ui_print ""
ui_print "[*] Consider saving the installation logs only in case of anything going wrong"
ui_print ""
ui_print "[*] You can choose between profiles and more by our CLI (su -c ktsrmenu) on a terminal (such as termux)"
ui_print ""
ui_print "Reboot to the changes be applied."
ui_print ""
mv -f "$MODPATH"/ktsr-cleanup.sh "$MODPATH"/../../service.d/
chmod 755 "$MODPATH"/../../service.d/ktsr-cleanup.sh
