#!/system/bin/sh
# KTSR™ by Pedro (pedrozzz0 @ GitHub)
# Thanks to hellokfl @ CoolApk, DavidPisces @ GitHub
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s).

modpath="/data/adb/modules/KTSR/"

echo 56 > /dev/sys/fs/by-name/userdata/data_io_flag
echo 56 > /dev/sys/fs/by-name/userdata/node_io_flag

# Wait to boot be completed
until [[ "$(getprop sys.boot_completed)" -eq "1" ]] || [[ "$(getprop dev.bootcomplete)" -eq "1" ]]; do
	sleep 1
done

# Pixels use this by default
echo 8 > /dev/sys/fs/by-name/userdata/data_io_flag
echo 8 > /dev/sys/fs/by-name/userdata/node_io_flag

# Update scripts once every reboot
wget -qO "${modpath}system/bin/kingtweaks" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kingtweaks"
wget -qO "${modpath}system/bin/kingd" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kingd"
wget -qO "${modpath}system/bin/gameoptd" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/gameoptd"
wget -qO "${modpath}libs/libktsr.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/libktsr.sh"
wget -qO "${modpath}libs/libcommon.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/libcommon.sh"
wget -qO "${modpath}system/bin/ktsrmenu" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/ktsrmenu"
wget -qO "${modpath}system/bin/cleantrash" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/cleantrash"
wget -qO "${modpath}mod-util.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/mod-util.sh"
wget -qO "${modpath}system/bin/kingun" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kingun"

[[ -e "${modpath}kcal.sh" ]] && {
	wget -qO "${modpath}kcal.sh" "https://raw.githubusercontent.com/pedrozzz0/King-Tweaks/master/kcal.sh"
	sh "${modpath}kcal.sh"
}

sleep 300

# Report max frequency to unity tasks
[[ -e "/proc/sys/kernel/sched_lib_mask_force" ]] && [[ -e "/proc/sys/kernel/sched_lib_name" ]] && {
	echo "UnityMain,libunity.so" >"/proc/sys/kernel/sched_lib_name"
	echo "255" >"/proc/sys/kernel/sched_lib_mask_force"
}

cleantrash &
kingtweaks
